def fact(n:int) ->int: 
    return 0

x:int = fact(12)
x # type: ignore
print(x+2) 
