import ast
import bs4
node = ast.parse("1+2")
print(node)
